define({
  "_themeLabel": "Tema Dart",
  "_layout_default": "Tata letak default"
});