define({
  "_themeLabel": "Piltema",
  "_layout_default": "Standardlayout"
});