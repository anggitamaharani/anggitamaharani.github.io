define({
  "_themeLabel": "飞镖主题",
  "_layout_default": "默认布局"
});