define({
  "_themeLabel": "Temă săgeţi",
  "_layout_default": "Aspect implicit"
});