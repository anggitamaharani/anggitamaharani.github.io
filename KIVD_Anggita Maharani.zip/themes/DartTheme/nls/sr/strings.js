define({
  "_themeLabel": "Tema Dart",
  "_layout_default": "Podrazumevani raspored"
});