define({
  "_themeLabel": "Tema de Lançamento",
  "_layout_default": "Layout padrão"
});