define({
  "_themeLabel": "ดาร์ทธีม",
  "_layout_default": "เค้าโครงเริ่มต้น"
});