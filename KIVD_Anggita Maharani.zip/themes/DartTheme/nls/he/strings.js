define({
  "_themeLabel": "ערכת נושא רצועה תחתונה",
  "_layout_default": "פריסת ברירת מחדל"
});