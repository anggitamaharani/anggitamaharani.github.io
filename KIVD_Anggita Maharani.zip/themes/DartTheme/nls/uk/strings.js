define({
  "_themeLabel": "Тема Dart",
  "_layout_default": "Компонування за замовчуванням"
});