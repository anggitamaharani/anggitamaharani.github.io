define({
  "_themeLabel": "Smiginio tema",
  "_layout_default": "Numatytasis maketas"
});