define({
  "_themeLabel": "Šautras tēma",
  "_layout_default": "Noklusējuma izkārtojums"
});