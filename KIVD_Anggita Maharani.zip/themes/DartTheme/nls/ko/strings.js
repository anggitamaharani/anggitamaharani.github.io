define({
  "_themeLabel": "다트 테마",
  "_layout_default": "기본 레이아웃"
});