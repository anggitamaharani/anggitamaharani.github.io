define({
  "_themeLabel": "Dart Teması",
  "_layout_default": "Varsayılan düzen"
});