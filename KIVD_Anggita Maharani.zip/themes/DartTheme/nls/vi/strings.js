define({
  "_themeLabel": "Chủ đề Phi tiêu",
  "_layout_default": "Bố cục mặc định"
});