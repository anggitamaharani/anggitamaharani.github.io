define({
  "_themeLabel": "Dartthema",
  "_layout_default": "Standaardlay-out"
});