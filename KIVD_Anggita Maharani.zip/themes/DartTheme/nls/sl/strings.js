define({
  "_themeLabel": "Puščica",
  "_layout_default": "Privzeta postavitev"
});