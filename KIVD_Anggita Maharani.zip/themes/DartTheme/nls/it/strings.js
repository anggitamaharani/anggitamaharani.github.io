define({
  "_themeLabel": "Tema Freccetta",
  "_layout_default": "Layout predefinito"
});