define({
  "_widgetLabel": "Dartkontroller"
});