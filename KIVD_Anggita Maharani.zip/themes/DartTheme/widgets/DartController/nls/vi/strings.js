define({
  "_widgetLabel": "Trình điều khiển Phi tiêu"
});