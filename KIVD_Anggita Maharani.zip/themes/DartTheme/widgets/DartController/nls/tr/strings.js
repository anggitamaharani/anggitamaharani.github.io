define({
  "_widgetLabel": "Dart Denetleyici"
});