define({
  "_widgetLabel": "Šautras kontrolleris"
});