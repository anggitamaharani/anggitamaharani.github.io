define({
  "_widgetLabel": "ตัวควบคุมดาร์ท"
});