define({
  "_widgetLabel": "Контроллер темы Дротика"
});