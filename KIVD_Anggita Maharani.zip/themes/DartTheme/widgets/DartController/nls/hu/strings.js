define({
  "_widgetLabel": "Dart vezérlő"
});