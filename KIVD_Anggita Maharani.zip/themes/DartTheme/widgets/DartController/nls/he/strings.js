define({
  "_widgetLabel": "בקר סרגל תחתון"
});