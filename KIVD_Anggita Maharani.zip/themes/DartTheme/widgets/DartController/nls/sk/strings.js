define({
  "_widgetLabel": "Ovládač Dart"
});