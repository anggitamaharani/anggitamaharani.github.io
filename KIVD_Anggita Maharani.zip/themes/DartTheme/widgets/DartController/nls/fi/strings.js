define({
  "_widgetLabel": "Nuolisäädin"
});