define({
  "_widgetLabel": "Pilhanteraren"
});