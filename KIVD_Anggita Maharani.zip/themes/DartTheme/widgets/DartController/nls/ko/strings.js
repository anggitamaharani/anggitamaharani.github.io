define({
  "_widgetLabel": "다트 컨트롤러"
});